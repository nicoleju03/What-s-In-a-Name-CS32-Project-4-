
// NameTable.cpp

// This is a correct but inefficient implementation of
// the NameTable functionality.

#include "NameTable.h"
#include <string>
#include <vector>
#include <functional>
#include <list>
#include <iostream>
using namespace std;

 // This class does the real work of the implementation.
class HashTable
{
public:
   HashTable() : buckets{}
   {
   }
    
   ~HashTable(){
       long size = scopeZero.size();
        for(int i=0; i<size; i++){
            unsigned long bucketNum = hashFunction(scopeZero[i]);
            if (buckets[bucketNum] != nullptr)
                delete buckets[bucketNum];
            buckets[bucketNum] = nullptr;
        }
   }
    
   bool add(const string& id, const int& line, const int& scope){
       unsigned long bucketNum = hashFunction(id);
       decl newDecl(id, line, scope);
       
       //if bucket is empty, add it to the list
       if(buckets[bucketNum]==nullptr){
           buckets[bucketNum] = new list<decl>;
           buckets[bucketNum]->push_back(newDecl);
           if(scope == 0){
               scopeZero.push_back(id);
           }
           return true;
       }
       
       //otherwise check if it's been declared in that scope
       list<decl>::iterator it = buckets[bucketNum]->begin();
       list<decl>::iterator end = buckets[bucketNum]->end();
       for(; it != end; it++){
           if((*it).m_id == id){
               if((*it).m_scope != scope){ //most recent is on top, the more nested scopes have been deleted, so this means it has not been  declared in the same scope
                   break;
               }
               return false; //if it was already declared in the same scope, return false
           }
       }
       //if not, add the new declaration it to the list
       
       if(scope == 0){
           scopeZero.push_back(id);
       }
       buckets[bucketNum]->push_front(newDecl); //most recent is in the front, makes it easier to search
       return true;
       
   }
   int find(const string& id) const{
       unsigned long bucketNum = hashFunction(id);
       list<decl>* bucketPtr =buckets[bucketNum];
       if(bucketPtr==nullptr){
           return -1;
       }
       list<decl>::iterator it = bucketPtr->begin();
       list<decl>::iterator end = bucketPtr->end();
       for(; it != end; it++){ //iterate through the list at that bucket
           if((*it).m_id == id){
               return (*it).m_line; //should be most recent since we add onto front
           }
       }
       return -1;
       
   }
   void remove(const string& id){ //removes the most recently added item in that bucket
       unsigned long bucketNum = hashFunction(id);
//       if(buckets[bucketNum]==nullptr){
//           return;
//       }
       if(buckets[bucketNum]->size()==1){
           delete buckets[bucketNum];
//           buckets[bucketNum]->pop_front();
           buckets[bucketNum] = nullptr;
           return;
       }
       buckets[bucketNum]->pop_front();
   }
private:
   struct decl {
       decl(const string& id, const int& line, const int& scope): m_id(id), m_line(line), m_scope(scope){
       }
       string m_id;
       int m_line;
       int m_scope;
   };
   list<decl>* buckets[19997]; //each bucket has a pointer to a list
    vector<string> scopeZero;
   unsigned long hashFunction(const string &hashMe) const{
       hash<string> str_hash;
       unsigned long hashVal = str_hash(hashMe);
       return hashVal % 19997;
   }
   
};
class NameTableImpl
{
 public:
   NameTableImpl();
   void enterScope();
   bool exitScope();
   bool declare(const string& id, const int& lineNum);
   int find(const string& id) const;
 private:
   int m_currScope;
   HashTable m_ht;
   vector<string> m_ids; //stores the scope id's
};

NameTableImpl::NameTableImpl(){
   m_currScope = 0;
}
void NameTableImpl::enterScope()
{
   m_currScope++;
   m_ids.push_back("");
}

bool NameTableImpl::exitScope()
{
   if(m_currScope == 0){
       return false;
   }
//   for(int i=0; i<m_ids.size(); i++){
//       m_ht.remove(m_ids[i]);
//   }
    while(m_ids.back() != ""){
        m_ht.remove(m_ids.back());
        m_ids.pop_back();
    }
   m_ids.pop_back();
   m_currScope--;
   return true;
   
}

bool NameTableImpl::declare(const string& id, const int& lineNum)
{
   if (id.empty())
       return false;
   
   if(m_ht.add(id,lineNum,m_currScope) == false){
       return false;
   } //the hash table's add function will return false if there was already a declaration in the same scope. Otherwise, it will add the declaration to the hash table
   else{
       m_ids.push_back(id); //add it to the current scope's ids
       return true;
   }

//      // Check for another declaration in the same scope.
//      // Return if found, break out if encounter the scope
//      // entry marker.
//
//    size_t k = m_ids.size();
//    while (k > 0)
//    {
//        k--;
//        if (m_ids[k].empty())
//            break;
//        if (m_ids[k] == id)
//            return false;
//    }
//
//      // Save the declaration
//
//    m_ids.push_back(id);
//    m_lines.push_back(lineNum);
//    return true;
}

int NameTableImpl::find(const string& id) const
{
   return m_ht.find(id);
//    if (id.empty())
//        return -1;
//
//      // Search back for the most recent declaration still
//      // available.
//
//    size_t k = m_ids.size();
//    while (k > 0)
//    {
//        k--;
//        if (m_ids[k] == id)
//            return m_lines[k];
//    }
//    return -1;
}

//*********** NameTable functions **************

// For the most part, these functions simply delegate to NameTableImpl's
// functions.

NameTable::NameTable()
{
   m_impl = new NameTableImpl;
}

NameTable::~NameTable()
{
   delete m_impl;
}

void NameTable::enterScope()
{
   m_impl->enterScope();
}

bool NameTable::exitScope()
{
   return m_impl->exitScope();
}

bool NameTable::declare(const string& id, int lineNum)
{
   return m_impl->declare(id, lineNum);
}

int NameTable::find(const string& id) const
{
   return m_impl->find(id);
}



